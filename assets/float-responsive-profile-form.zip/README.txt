A Pen created at CodePen.io. You can find this one at http://codepen.io/soulrider911/pen/ZGqKVq.

 A responsive user profile form, with floated labels, and password visibility toggle. 