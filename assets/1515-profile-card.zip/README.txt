A Pen created at CodePen.io. You can find this one at http://codepen.io/alex_zy/pen/LjPjzb.

 Profile card with bordered image and profile details